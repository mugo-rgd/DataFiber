# Changelog

All notable changes to `laravel-eloquent-spatial` will be documented in this file.

## v4.6.1 - 2026-02-26

### What's Changed

* Add EWKT parsing support to fromWkt by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/145

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.6.0...4.6.1

## v4.6.0 - 2026-02-01

### What's Changed

* Replace phayes/geophp with brick/geo by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/142

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.5.0...4.6.0

## v4.5.0 - 2025-02-26

### What's Changed

* Laravel 12 upgrade by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/136

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.4.1...4.5.0

## v4.4.1 - 2024-11-30

### What's Changed

* Fix WKT for empty geometry collections by @LachlanArthur in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/132

### New Contributors

* @LachlanArthur made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/132

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.4.0...4.4.1

## v4.4.0 - 2024-11-23

### What's Changed

* Allow setting default SRID by @MatanYadaev  in https://github.com/MatanYadaev/laravel-eloquent-spatial/commit/43edde698892659c9ef28b83a774f62a91ff7559

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.3.2...4.4.0

## v4.3.2 - 2024-08-07

### What's Changed

* Fix SRID not being optional for expression in GeometryCast by @nickknissen in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/124

### New Contributors

* @nickknissen made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/124

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.3.1...4.3.2

## v4.3.1 - 2024-08-03

### What's Changed

* Fix columns that their cast is `Geometry` by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/127

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.3.0...4.3.1

## v4.3.0 - 2024-07-24

### What's Changed

* Support Geometry class extension by @jobverplanke in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/125

### New Contributors

* @jobverplanke made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/125

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.2.1...4.3.0

## v4.2.0 - 2024-03-13

### What's Changed

* Support Laravel 11 by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/113

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.1.1...4.2.0

## v4.1.1 - 2024-03-05

### What's Changed

* Laravel Pint by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/112
* Bugfix: `isDirty` is always `true` after creation by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/115

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.1.0...4.1.1

## v4.1.0 - 2024-02-24

### What's Changed

* Postgres support by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/109

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/4.0.0...4.1.0

## v4.0.0 - 2024-01-18

### What's Changed

* Moved away from spatialbuilder to scopes by @yinx in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/102
* Allow srid enum as srid property aside from integer by @yinx in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/103
* Add php 8.3 support by @gdebrauwer in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/105

### New Contributors

* @yinx made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/102
* @gdebrauwer made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/105

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/3.2.2...4.0.0

## v3.2.2 - 2024-01-05

- Revert v3.2.1 changes

## v3.2.1 - 2023-12-28

- Fixed model serialization bug #100

## v3.2.0 - 2023-06-25

### What's Changed

- Support `St_Centroid` spatial function

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/3.1.2...3.2.0

## v2.10.1 - 2023-03-09

### What's Changed

- Bugfix: Model spatial column update using Expression by @hiteshsamcom in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/86

### New Contributors

- @hiteshsamcom made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/86

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/2.10.0...2.10.1

## v3.1.2 - 2023-02-28

### What's Changed

- Add SRID Enum by @Riley19280 in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/84

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/3.1.1...3.1.2

## v3.1.1 - 2023-02-16

### What's Changed

- Bugfix: Model spatial column update using Expression by @MatanYadaev in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/81

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/3.1.0...3.1.1

## v3.1.0 - 2023-02-06

### What's Changed

- Support receiving `Expression` as a parameter in `SpatialBuilder` methods by @Riley19280 in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/76

### New Contributors

- @Riley19280 made their first contribution in https://github.com/MatanYadaev/laravel-eloquent-spatial/pull/76

**Full Changelog**: https://github.com/MatanYadaev/laravel-eloquent-spatial/compare/3.0.0...3.1.0

## v3.0.0 - 2023-02-03

Support Larave 10

## v2.10.0 - 2023-01-25

Support PHP 8.2 #74

## v2.9.0 - 2023-01-09

Add HasSpatial trait #75

## v2.8.0 - 2022-12-12

- Cast geometry from array #71
- Add `Geometry@toSqlExpression` method #70

## v2.7.0 - 2022-10-06

Macroable geometry classes

## v2.6.0 - 2022-10-06

Add Doctrine types

## v2.5.2 - 2022-09-27

Query Builder - Support column to have table name #61

## v2.5.1 - 2022-09-24

Geometry objects are now stringable.

## v2.5.0 - 2022-09-23

Support MySQL 5.7

## v2.4.0 - 2022-09-22

- Add `whereNotWithin` Builder method
- Add `whereNotContains` Builder method

## v2.3.0 - 2022-09-06

Added MariaDB support

## v2.2.0 - 2022-08-29

Fix `axis-order` when using SRID

## v2.1.1 - 2022-07-20

Refactor `toWkt`

## v2.1.0 - 2022-07-20

- SRID support
- Add `Geometry@toWkt`
- Add `Geometry@toWkb`
- Fix generic type issue with `GeometryCollection`

## v2.0.1 - 2022-07-12

Make `Geometry::toWkt` parameters optional

## v2.0.0 - 2022-07-08

Improve casting:

- Fix `getOriginal`
- Use a more standard WKT format

## 1.0.4 - 2022-03-07

- Fix PHPStan issues

## 1.0.3 - 2022-02-24

- Support Laravel 9
- Support PHP 8.1

## 1.0.2 - 2021-08-31

- Remove auto-discovery part from composer.json

## 1.0.1 - 2021-08-11

- Upgrade to PHP-CS-Fixer v3 and clear PHPStan issues

## 1.0.0 - 2021-02-23

- Initial release
